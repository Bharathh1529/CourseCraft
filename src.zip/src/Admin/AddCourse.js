import React, { useState } from 'react';
import './AddCourse.css';

const AddCourse = ({ onAddCourse }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [instructor, setInstructor] = useState('');
    const [image, setImage] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (title && description && instructor && image) {
            onAddCourse({ title, description, instructor, image });
            setTitle('');
            setDescription('');
            setInstructor('');
            setImage('');
        } else {
            alert('Please fill out all fields.');
        }
    };

    return (
        <div className='add-course-container'>
            <h2>Add New Course</h2>
            <form onSubmit={handleSubmit} className='add-course-form'>
                <div className='form-group'>
                    <label htmlFor='title'>Course Title:</label>
                    <input
                        type='text'
                        id='title'
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                    />
                </div>
                <div className='form-group'>
                    <label htmlFor='description'>Description:</label>
                    <textarea
                        id='description'
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                    />
                </div>
                <div className='form-group'>
                    <label htmlFor='instructor'>Instructor:</label>
                    <input
                        type='text'
                        id='instructor'
                        value={instructor}
                        onChange={(e) => setInstructor(e.target.value)}
                    />
                </div>
                <div className='form-group'>
                    <label htmlFor='image'>Image URL:</label>
                    <input
                        type='text'
                        id='image'
                        value={image}
                        onChange={(e) => setImage(e.target.value)}
                    />
                </div>
                <button type='submit' className='submit-button'>Add Course</button>
            </form>
        </div>
    );
};

export default AddCourse;
