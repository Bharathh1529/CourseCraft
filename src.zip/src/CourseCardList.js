import React, { useState } from 'react';
import CourseCard from './CourseCard';
import './CourseCardList.css';
import Header from './Header';
import Footer from './Footer';

const courses = [
    { title: 'History of Art', description: 'Explore the history of art from ancient times to the modern era.', instructor: 'Dr. Jane Smith', image: 'path/to/art-history.jpg' },
    { title: 'Modern Physics', description: 'Dive into the principles of modern physics and its applications.', instructor: 'Prof. John Doe', image: 'path/to/physics.jpg' },
    { title: 'Introduction to Literature', description: 'Discover the world of literature, including poetry, novels, and more.', instructor: 'Prof. Emma Wilson', image: 'path/to/literature.jpg' },
    { title: 'Biology for Beginners', description: 'Learn the basics of biology, including cell structure, genetics, and ecosystems.', instructor: 'Dr. Mike Johnson', image: 'path/to/biology.jpg' },
    { title: 'Chemistry Essentials', description: 'Understand the fundamental concepts of chemistry.', instructor: 'Dr. Alice Brown', image: 'path/to/chemistry.jpg' },
    { title: 'Philosophy: An Overview', description: 'A comprehensive look at the major philosophical ideas and thinkers.', instructor: 'Dr. Laura Green', image: 'path/to/philosophy.jpg' },
    { title: 'Classical Music Appreciation', description: 'Explore the world of classical music and its greatest composers.', instructor: 'Prof. David White', image: 'path/to/classical-music.jpg' },
    { title: 'Environmental Science', description: 'Learn about environmental issues and sustainable solutions.', instructor: 'Dr. Sarah Black', image: 'path/to/environmental-science.jpg' },
    { title: 'Psychology Fundamentals', description: 'An introduction to the science of mind and behavior.', instructor: 'Dr. Robert Lee', image: 'path/to/psychology.jpg' }
];

const CourseCardList = () => {
    const [searchTerm, setSearchTerm] = useState('');

    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
    };

    const filteredCourses = courses.filter(course =>
        course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.instructor.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <Header/>
            <div className='course-card-list-container'>
                <div className='search-bar'>
                    <input
                        type='text'
                        placeholder='Search for courses...'
                        value={searchTerm}
                        onChange={handleSearch}
                    />
                </div>
                <div className='course-card-list'>
                    {filteredCourses.length > 0 ? (
                        filteredCourses.map((course, index) => (
                            <CourseCard
                                key={index}
                                title={course.title}
                                description={course.description}
                                instructor={course.instructor}
                                image={course.image}
                            />
                        ))
                    ) : (
                        <p>No courses found.</p>
                    )}
                </div>
            </div>
            <Footer/>
        </div>
    );
}

export default CourseCardList;
