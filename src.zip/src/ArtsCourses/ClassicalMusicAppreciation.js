import React, { useState, useEffect } from 'react';
import '../CourseDetail.css'; 
import img from '../Photos/classicalMusic.png'; // Update with the correct path
import Header from '../Header';
import Footer from '../Footer';
import { useNavigate } from 'react-router-dom';

const ClassicalMusicAppreciation = () => {
  const [activeTab, setActiveTab] = useState('About');
  const [enrolled, setEnrolled] = useState(false);
  const navigate = useNavigate();
  const courseKey = 'enrolledClassicalMusicAppreciation'; // Unique key for this course

  const scrollToSection = (section) => {
    setActiveTab(section);
    document.getElementById(section).scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    const enrollmentStatus = sessionStorage.getItem(courseKey);
    if (enrollmentStatus === 'true') {
      setEnrolled(true);
    }
  }, []);

  const handleEnrollClick = () => {
    navigate('/Payment', { state: { from: '/ClassicalMusicAppreciation', courseKey } });
  };

  const handleExploreNowClick = () => {
    navigate('/ClassicalMusicLectures'); // Replace with the appropriate path
  };

  return (
    <div className='CourseDetail'>
      <Header />
      <div className="course-detail-page">
        <div className="course-header">
          <div className="course-header-content">
            <h1>Classical Music Appreciation</h1>
            <p className="course-description">
              Discover the rich and diverse world of classical music with this comprehensive course. From Baroque to Romantic, explore the history, key composers, and essential works that have shaped classical music.
            </p>
            <p className="course-instructor">
              Instructor: <a href="#">Dr. Robert Smith</a>, musicologist and expert in classical music.
            </p>
            {!enrolled ? (
              <button onClick={handleEnrollClick} className='EnrollButton'>Enroll</button>
            ) : (
              <button onClick={handleExploreNowClick} className='ExploreButton'>Explore Now</button>
            )}
            <p className="start-date">Starts Nov 10</p>
            <p className="enrolled-count">150,000 already enrolled</p>
          </div>
        </div>
        <div className="course-sidebar">
          <p><strong>Specialization - Introduction to Classical Music</strong></p>
          <p>Gain an in-depth understanding of classical music’s evolution and its major works</p>
          <p className="rating">4.9 ★ (88,564 reviews)</p>
          <p>Beginner to Intermediate level</p>
          <p>No prior music knowledge required</p>
          <p>4 months at 5 hours a week</p>
          <p>Flexible schedule</p>
          <p>Learn at your own pace</p>
          <a href="#" className="view-all-courses">View all courses</a>
        </div>
      </div>

      <div className="tabs">
        <button onClick={() => scrollToSection('About')} className={activeTab === 'About' ? 'active' : ''}>About</button>
        <button onClick={() => scrollToSection('Outcomes')} className={activeTab === 'Outcomes' ? 'active' : ''}>Outcomes</button>
        <button onClick={() => scrollToSection('Courses')} className={activeTab === 'Courses' ? 'active' : ''}>Courses</button>
      </div>

      <div className="content">
        <div id="About" className="tab-content">
          <h2>Skills You'll Gain</h2>
          <p>This course provides a comprehensive overview of classical music. You will gain skills in:</p>
          <div className="skills">
            <span>Historical Context</span>
            <span>Music Analysis</span>
            <span>Composer Recognition</span>
            <span>Listening Skills</span>
            <span>Musical Forms</span>
            <span>Performance Appreciation</span>
            <span>Cultural Impact</span>
            <span>Critical Listening</span>
          </div>
          <h2>Details to Know</h2>
          <p>Upon completion, you will earn a certificate demonstrating your knowledge of classical music. This course is ideal for those looking to deepen their appreciation and understanding of classical compositions.</p>
          <p>You'll explore key periods, styles, and influential composers, enhancing your ability to listen to and analyze classical music effectively.</p>
        </div>

        <div id="Outcomes" className="tab-content">
          <div className="outcome-container">
            <div className="outcome-details">
              <h2>Enhance Your Musical Knowledge</h2>
              <p>By completing this course, you will deepen your appreciation of classical music. The course aims to:</p>
              <ul>
                <li>Introduce major classical music periods and styles.</li>
                <li>Develop skills in music analysis and critical listening.</li>
                <li>Provide insights into the lives and works of key composers.</li>
                <li>Prepare you to appreciate classical music in various contexts, from casual listening to academic study.</li>
              </ul>
              <p>These outcomes will help you gain a richer understanding of classical music and its place in cultural history.</p>
            </div>
            <div className="outcome-image">
              <img src={img} alt="Outcome Illustration" />
            </div>
          </div>
        </div>

        <div id="Courses" className="tab-content">
          <h2>Courses Included in the Specialization</h2>
          <p>This specialization includes several courses that provide a deep dive into classical music. The courses are:</p>
          <ul>
            <li>Introduction to Classical Music: Overview of key periods, styles, and composers.</li>
            <li>Baroque Music: Explore the music of Bach, Handel, and Vivaldi.</li>
            <li>Classical Period Music: Study the works of Mozart, Haydn, and Beethoven.</li>
            <li>Romantic Music: Examine the compositions of Chopin, Wagner, and Tchaikovsky.</li>
            <li>20th Century Classical Music: Understand the evolution of music in the 20th century and beyond.</li>
            <li>Music Appreciation: Develop skills in listening to and analyzing classical music.</li>
            <li>Composers and Their Works: In-depth studies of significant composers and their contributions.</li>
          </ul>
          <p>Each course combines lectures, listening assignments, and discussions to ensure a thorough understanding of classical music. Engage with interactive content and connect with peers and instructors.</p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ClassicalMusicAppreciation;
