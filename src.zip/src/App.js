// App.js
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Landing from './Landing';
import Login from './Login';
import Signup from './Signup';
import CourseCardList from './CourseCardList';
import CourseDetail from './CourseDetail';
import About from './About';
import Profession from './Profession';
import { UserProvider } from './UserContext';
import AdminPannel from './Admin/AdminPannel';
import AddCourse from './Admin/AddCourse';
import ArtsVideoPage from './VideoPages/ArtsVideoPage';
import PaymentPage from './Payment/PaymentPage';
import ModernPhysics from './ArtsCourses/ModernPhysics';
import IntroductionToLiterature from './ArtsCourses/IntroductionToLiterature';
import BiologyForBeginners from './ArtsCourses/BiologyForBeginners';
import ChemistryEssentials from './ArtsCourses/ChemistryEssentials';
import PhilosophyOverview from './ArtsCourses/PhilosophyOverview';
import ClassicalMusicAppreciation from './ArtsCourses/ClassicalMusicAppreciation';
import EnvironmentalScience from './ArtsCourses/EnvironmentalScience';
import PsychologyFundamentals from './ArtsCourses/PsychologyFundamentals';
function App() {
  return (
    <UserProvider>
      <div className="App">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path='/Login' element={<Login />} />
          <Route path='/Signup' element={<Signup />} />
          <Route path='/Arts&ScienceCourses' element={<CourseCardList/>}/>
          <Route path='/HistoryOfArts' element={<CourseDetail/>}/>
          <Route path='/About' element={<About/>}/>
          <Route path='/Profession' element={<Profession/>}/>
          <Route path='/AdminDashboard' element={<AdminPannel/>}/>
          <Route path='/AddCourse' element={<AddCourse/>}/>
          <Route path='/HistroyOfArtsLectures' element={<ArtsVideoPage/>}/>
          <Route path='/Payment' element={<PaymentPage/>}/>
          <Route path='/ModernPhysics' element={<ModernPhysics/>}/>
          <Route path='/IntroductionToLiteratrue' element={<IntroductionToLiterature/>}/>
          <Route path='/BiologyForBeginners' element={<BiologyForBeginners/>}/>
          <Route path='/ChemistryEssentials' element={<ChemistryEssentials/>}/>
          <Route path='/PhilosophyOverview' element={<PhilosophyOverview/>}/>
          <Route path='/ClassicalMusicAppreciation' element={<ClassicalMusicAppreciation/>}/>
          <Route path='/EnvironmentalScience' element={<EnvironmentalScience/>}/>
          <Route path='/PsychologyFundamentals' element={<PsychologyFundamentals/>}/>
        </Routes>
      </div>
    </UserProvider>
  );
}

export default App;
