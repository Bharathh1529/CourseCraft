import React, { useState } from 'react';
import './Login.css';
import pic from './Photos/Login.jpg';
import { useNavigate } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';

const Login = () => {
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const saveEmail = (e) => {
        setEmail(e.target.value);
    };

    const savePassword = (e) => {
        setPassword(e.target.value);
    };

    const saveDetails = async (e) => {
        e.preventDefault();
        if (!email || !password) {
            setError('Please fill in all fields');
            return;
        }
        console.log(email,password);
        try {
            const response = await fetch("http://localhost:8080/CourseCraft/login", {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    email,
                    password
                }),
            });

            if (response.ok) {
                if(email==='bharath@craft.in' && password==='bhbh')
                {
                    navigate('/AdminDashboard');
                }
                else
                {
                    navigate("/"); 
                }
            } else {
                const errorMessage = await response.text();
                setError(errorMessage);
            }
        } catch (error) {
            console.log(error);
            setError('An error occurred. Please try again.');
        }
    };

    return (
        <div>
            <Header />
            <div className='login-page'>
                <div className='login-visual'>
                    <img src={pic} alt='Study visual' />
                </div>
                <div className='login-form'>
                    <p>Login</p>
                    <form className='form' onSubmit={saveDetails}>
                        <label>
                            UserName or Email
                            <span>*</span>
                        </label>
                        <input
                            type='email'
                            value={email}
                            onChange={saveEmail}
                            placeholder='Enter your email'
                        />
                        <label>
                            Password
                            <span>*</span>
                        </label>
                        <input
                            type='password'
                            value={password}
                            onChange={savePassword}
                            placeholder='Enter your password'
                        />
                        {error && <p className='error-message'>{error}</p>}
                        <button type='submit'>Submit</button>
                        <div className='form-footer'>
                            <a href='#forgot-password'>Forgot Password?</a>
                            <a href='#create-account'>Don't have an account? Create an account</a>
                        </div>
                    </form>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default Login;
