import React from 'react';
import { useNavigate } from 'react-router-dom';
import './CourseCard.css';
import historyOfArtImage from './Photos/historyOfArts.jpg';
import modernPhysicsImage from './Photos/ModernPhysics.jpg';
import literatureImage from './Photos/Introduction To Literature.jpeg.jpg';
import biologyImage from './Photos/biologyImage.jpeg';
import chemistryImage from './Photos/chemistryImage.jpg';
import philosophyImage from './Photos/Philosophy.jpg';
import classicalMusicImage from './Photos/classicalMusic.png';
import environmentalScienceImage from './Photos/EnvironmentalScience.webp';
import psychologyImage from './Photos/psychologyImage.jpg';

const CourseCard = ({ title, description, instructor }) => {
    const navigate = useNavigate();

    const handleViewCourse = () => {
        if (title === 'History of Art') {
            navigate('/HistoryOfArts');
        } else if (title === 'Environmental Science') {
            navigate('/EnvironmentalScience');
        }
        else if(title === 'Modern Physics')
        {
            navigate('/ModernPhysics')
        }
        else if(title === 'Biology for Beginners')
        {
            navigate('/BiologyForBeginners')
        }
        else if(title === 'Introduction to Literature')
        {
            navigate('/IntroductionToLiteratrue')
        }
        else if(title === 'Chemistry Essentials')
        {
            navigate('/ChemistryEssentials')
        }
        else if(title === 'Philosophy: An Overview')
        {
            navigate('/PhilosophyOverview')
        }
        else if(title === 'Classical Music Appreciation')
        {
            navigate('/ClassicalMusicAppreciation')
        }
        else if(title === 'Environmental Science')
        {
            navigate('/EnvironmentalScience')
        }
        else if(title === 'Psychology Fundamentals')
        {
            navigate('/PsychologyFundamentals')
        }
    };

    const getImage = (courseTitle) => {
        switch (courseTitle) {
            case 'History of Art':
                return historyOfArtImage;
            case 'Modern Physics':
                return modernPhysicsImage;
            case 'Introduction to Literature':
                return literatureImage;
            case 'Biology for Beginners':
                return biologyImage;
            case 'Chemistry Essentials':
                return chemistryImage;
            case 'Philosophy: An Overview':
                return philosophyImage;
            case 'Classical Music Appreciation':
                return classicalMusicImage;
            case 'Environmental Science':
                return environmentalScienceImage;
            case 'Psychology Fundamentals':
                return psychologyImage;
        }
    };

    return (
        <div className='course-card'>
            <img src={getImage(title)} alt={title} className='course-image' />
            <div className='course-details'>
                <h2 className='course-title'>{title}</h2>
                <p className='course-description'>{description}</p>
                <p className='course-instructor'>Instructor: {instructor}</p>
                <button className='enroll-button' onClick={handleViewCourse}>
                    View Course
                </button>
            </div>
        </div>
    );
};

export default CourseCard;
